/*
 * define boolean type here
 *
 * TRUE means 1
 * FALSE means 0
 */

#ifndef BOOLEAN_H
#define BOOLEAN_H

typedef int boolean;
#define TRUE 1
#define FALSE 0

#endif
