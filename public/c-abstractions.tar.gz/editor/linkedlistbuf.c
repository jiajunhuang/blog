#include <stdio.h>
#include "buffer.h"
#include "genlib.h"

/*
 * every node contains two parts
 * * element
 * * pointer to next element
 */
typedef struct cellT {
  char ch;
  struct cellT *link;
}cellT;

/*
 * this Node tells us where is the start node
 */

struct bufferCDT {
  cellT *start;
  cellT *cursor;
};

/*
 * Implementation notes: NewBuffer
 *
 * This function allocates an empty editor buffer, represented as a linked 
 * list. To simplify the link operation, this implementation adopts the useful
 * programming tactic of keepint an extra "dummy" cell at the beginning of 
 * each list, so that the empty buffer has the following representation.
 */

bufferADT NewBuffer()
{
  bufferADT buffer;

  buffer = New(bufferADT);
  buffer->start = buffer->cursor = New(cellT *);
  buffer->start->link = NULL;

  return (buffer);
}

/*
 * Implementation notes: FreeBuffer
 *
 * FreeBuffer must free every cell in the buffer as well as the buffer storage
 * itself. Note that the loop structure is not exactly the standard idiom for 
 * processing every cell within a linked list, because  it is not legal to free
 * a cell and later look at its link field. To avoid selecting fields in the 
 * structure after it has been freed, you have to copy the link pointer before
 * calling FreeBlock.
 */

void FreeBuffer(bufferADT buffer)
{
  cellT *cp, *next;

  cp = buffer->start;
  while(cp != NULL) {
    next = cp->link;
    FreeBlock(cp);
    cp = next;
  }
  FreeBlock(buffer);
}

void MoveCursorForward(bufferADT buffer)
{
  if (buffer->cursor->link != NULL) {
    buffer->cursor = buffer->cursor->link;
  }
}

/*
 * because this is a singly linked list, so we can not find the previous node 
 * directly
 */

void MoveCursorBackward(bufferADT buffer)
{
  cellT *cp;

  if (buffer->cursor != buffer ->start) {
    cp = buffer->start;
    while(cp->link != buffer->cursor) {
      cp = cp->link;
    }
    buffer->cursor = cp;
  }
}

void MoveCursorToStart(bufferADT buffer)
{
  buffer->cursor = buffer->start;
}

void MoveCursorToEnd(bufferADT buffer)
{
  while(buffer->cursor->link != NULL) {
    /*buffer->cursor = buffer->cursor->link;*/
    // or you can do it with
    MoveCursorForward(buffer);
  }
}

void InsertCharacter(bufferADT buffer, char ch)
{
  cellT *cp;

  cp = New(cellT *);
  cp->ch = ch;
  /*
   * if we use the current cursor, it may be "dummy" node,
   * so we use the buffer->cursor-link, after insertion, then move the cursor
   * after the insert node.
   */
  cp->link = buffer->cursor->link;
  buffer->cursor->link = cp;
  buffer->cursor = cp;
}

void DeleteCharacter(bufferADT buffer)
{
  cellT *cp;

  if (buffer->cursor->link != NULL) {
    cp = buffer->cursor->link;
    buffer->cursor->link = cp->link;
    FreeBlock(cp);
  }
}

void DisplayBuffer(bufferADT buffer)
{
  cellT *cp;
  
  for(cp = buffer->start->link; cp != NULL; cp = cp->link) {
    printf(" %c", cp->ch);
  }
  printf("\n");
  for(cp = buffer->start; cp != buffer->cursor; cp = cp->link) {
    printf("  ");
  }
  printf("^\n");
}
